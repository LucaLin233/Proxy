#!/usr/bin/env python3
"""Control Surge iOS through its localhost HTTP API."""
import argparse, json, os, re, sys
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen

BASE = os.getenv("SURGE_HTTP_API_BASE", "http://127.0.0.1:6171").rstrip("/")
KEY = os.getenv("SURGE_API_KEY")


def redact(text):
    """抹掉文本中的凭据值：认证字段、JSON/引号形式（含转义、单引号键、平面数组）、裸键值、token 前缀。"""
    text = str(text)
    auth = r"(?:authorization|proxy-authorization|auth|authz)"
    scheme = r"(?:bearer|basic|digest|negotiate|ntlm|aws4-hmac-sha256)"
    key = (r"(?:password|passwd|pwd|psk|username|user|private[-_]key|token|api[-_]?key"
           r"|x[-_]key|secret|credential)")
    dq = r'"(?:[^"\\]|\\.)*"'
    sq = r"'(?:[^'\\]|\\.)*'"
    # 1a) 认证字段的引号值（JSON/结构化形态；键与值之间允许换行缩进，覆盖多行 JSON）
    text = re.sub(r'(?i)(?P<qk>["\']?)\b(?P<ak>' + auth + r')\b(?P=qk)'
                  r'(?P<sep>\s*[:=]\s*)(?P<q>["\'])(?:[^"\'\\]|\\.)*(?P=q)',
                  lambda m: '%s%s%s%s%s<redacted>%s' % (m.group('qk'), m.group('ak'), m.group('qk'),
                                                        m.group('sep'), m.group('q'), m.group('q')),
                  text)
    # 1b) 认证字段带方案词（Bearer/Basic/Digest/...）→ 取该字段整行值，覆盖逗号多段与 Digest 参数
    text = re.sub(r'(?i)(?P<qk>["\']?)\b(?P<ak>' + auth + r')\b(?P=qk)'
                  r'(?P<sep>[ \t]*[:=][ \t]*)(?P<val>' + scheme + r'\b[^\n]*)',
                  lambda m: '%s%s%s%s"<redacted>"' % (m.group('qk'), m.group('ak'), m.group('qk'), m.group('sep')),
                  text)
    # 1c) 其余认证字段值：止于逗号/分号/换行，不吞同一行的普通诊断字段（如 status=502）；
    #     值已是抹除标记时原样返回，避免二次匹配吃掉尾随结构（如 JSON 的 } ）
    def _auth_bare(m):
        v = m.group('val')
        if v.startswith('"<redacted>"') or v.startswith("'<redacted>'") or v.startswith('<redacted>'):
            return m.group(0)
        return '%s%s%s%s"<redacted>"' % (m.group('qk'), m.group('ak'), m.group('qk'), m.group('sep'))
    text = re.sub(r'(?i)(?P<qk>["\']?)\b(?P<ak>' + auth + r')\b(?P=qk)'
                  r'(?P<sep>[ \t]*[:=][ \t]*)(?P<val>[^\n,;]+)', _auth_bare, text)
    # 2) 敏感键的数组/对象值（如 {"token":["x"]}）：整段值替换
    text = re.sub(r'(?i)(?P<qk>["\']?)\b(?P<k>' + key + r')\b(?P=qk)(?P<sep>\s*:\s*)(\[[^\[\]]*\]|\{[^{}]*\})',
                  lambda m: '%s%s%s%s["<redacted>"]' % (m.group('qk'), m.group('k'), m.group('qk'), m.group('sep')),
                  text)
    # 3) 带引号的值（键可带引号，值支持转义引号）
    text = re.sub(r'(?i)(?P<qk>["\']?)\b(?P<k>' + key + r')\b(?P=qk)(?P<sep>\s*[:=]\s*)(?P<val>' + dq + '|' + sq + r')',
                  lambda m: '%s%s%s%s%s<redacted>%s' % (m.group('qk'), m.group('k'), m.group('qk'),
                                                        m.group('sep'), m.group('val')[0], m.group('val')[0]),
                  text)
    # 4) 裸值：以逗号/分号/空白为界
    text = re.sub(r"(?i)\b(" + key + r")\b\s*[:=]\s*[^\s,;]+", r"\1=<redacted>", text)
    # 5) 已知 token 前缀
    return re.sub(r"(?i)\b(sk|ghp|github_pat|xox[baprs])[-_][A-Za-z0-9_-]{16,}", "<redacted>", text)


def fail(message, code=2):
    print(redact(message), file=sys.stderr)
    raise SystemExit(code)


def validate_base():
    parsed = urlparse(BASE)
    if parsed.scheme not in ("http", "https"):
        fail("SURGE_HTTP_API_BASE must use http or https")
    if parsed.hostname not in ("127.0.0.1", "localhost", "::1") and os.getenv("SURGE_ALLOW_REMOTE") != "1":
        fail("Remote Surge API blocked; set SURGE_ALLOW_REMOTE=1 explicitly")
    if not KEY:
        fail("SURGE_API_KEY is not set")


def request(method, path, body=None, dangerous=False, confirm=False):
    validate_base()
    if not path.startswith("/v1/"):
        fail("API path must start with /v1/")
    if "sensitive=1" in path and os.getenv("SURGE_ALLOW_SENSITIVE") != "1":
        fail("Sensitive profile export blocked; set SURGE_ALLOW_SENSITIVE=1 explicitly")
    if dangerous and not confirm:
        fail("This action requires --confirm-dangerous")
    data = None if body is None else json.dumps(body).encode()
    headers = {"X-Key": KEY, "Accept": "application/json"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    req = Request(BASE + path, data=data, headers=headers, method=method)
    try:
        with urlopen(req, timeout=30) as response:
            raw = response.read()
            ctype = response.headers.get("Content-Type", "")
    except HTTPError as e:
        detail = e.read().decode("utf-8", "replace")
        fail(f"HTTP {e.code}: {detail}", 1)
    except URLError as e:
        fail(f"Cannot reach Surge API at {BASE}: {e.reason}", 1)
    if "json" in ctype or raw[:1] in (b"{", b"["):
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            pass
    return raw.decode("utf-8", "replace")


def show(value):
    if isinstance(value, (dict, list)):
        print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(value)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--confirm-dangerous", action="store_true")
    sub = p.add_subparsers(dest="command", required=True)
    raw = sub.add_parser("request", help="Call an API endpoint")
    raw.add_argument("method", choices=("GET", "POST"))
    raw.add_argument("path")
    raw.add_argument("json_body", nargs="?")
    sub.add_parser("status")
    outbound = sub.add_parser("outbound")
    outbound.add_argument("mode", nargs="?", choices=("direct", "proxy", "rule"))
    feature = sub.add_parser("feature")
    feature.add_argument("name", choices=("mitm", "capture", "rewrite", "scripting"))
    feature.add_argument("state", nargs="?", choices=("on", "off"))
    sub.add_parser("policies")
    sub.add_parser("groups")
    select = sub.add_parser("select")
    select.add_argument("group")
    select.add_argument("policy", nargs="?")
    recent = sub.add_parser("requests")
    recent.add_argument("kind", choices=("recent", "active"), default="recent", nargs="?")
    kill = sub.add_parser("kill")
    kill.add_argument("id", type=int)
    sub.add_parser("profile")
    sub.add_parser("reload")
    sub.add_parser("dns")
    sub.add_parser("flush-dns")
    sub.add_parser("modules")
    module = sub.add_parser("module")
    module.add_argument("name")
    module.add_argument("state", choices=("on", "off"))
    for name in ("events", "rules", "traffic"):
        sub.add_parser(name)
    sub.add_parser("metrics", help="Read Prometheus metrics from /v1/metrics")
    sub.add_parser("stop")
    args = p.parse_args()

    c = args.command
    if c == "request":
        body = json.loads(args.json_body) if args.json_body else None
        show(request(args.method, args.path, body,
                     dangerous=args.path == "/v1/stop", confirm=args.confirm_dangerous))
    elif c == "status":
        result = {
            "outbound": request("GET", "/v1/outbound"),
            "features": {n: request("GET", f"/v1/features/{n}") for n in ("mitm", "capture", "rewrite", "scripting")},
        }
        show(result)
    elif c == "outbound":
        show(request("POST", "/v1/outbound", {"mode": args.mode}) if args.mode else request("GET", "/v1/outbound"))
    elif c == "feature":
        path = f"/v1/features/{args.name}"
        show(request("POST", path, {"enabled": args.state == "on"}) if args.state else request("GET", path))
    elif c == "policies": show(request("GET", "/v1/policies"))
    elif c == "groups": show(request("GET", "/v1/policy_groups"))
    elif c == "select":
        if args.policy:
            groups = request("GET", "/v1/policy_groups")
            if args.group not in groups:
                fail(f"Unknown policy group: {args.group}")
            available = {item.get("name") for item in groups[args.group] if item.get("enabled", True)}
            if args.policy not in available:
                fail(f"Policy is not an enabled option of {args.group}: {args.policy}")
            show(request("POST", "/v1/policy_groups/select", {"group_name": args.group, "policy": args.policy}))
        else:
            show(request("GET", "/v1/policy_groups/select?" + urlencode({"group_name": args.group})))
    elif c == "requests": show(request("GET", f"/v1/requests/{args.kind}"))
    elif c == "kill": show(request("POST", "/v1/requests/kill", {"id": args.id}))
    elif c == "profile": show(request("GET", "/v1/profiles/current?sensitive=0"))
    elif c == "reload": show(request("POST", "/v1/profiles/reload", {}))
    elif c == "dns": show(request("GET", "/v1/dns"))
    elif c == "flush-dns": show(request("POST", "/v1/dns/flush", {}))
    elif c == "modules": show(request("GET", "/v1/modules"))
    elif c == "module": show(request("POST", "/v1/modules", {args.name: args.state == "on"}))
    elif c in ("events", "rules", "traffic"): show(request("GET", f"/v1/{c}"))
    elif c == "metrics": show(request("GET", "/v1/metrics"))
    elif c == "stop": show(request("POST", "/v1/stop", {}, dangerous=True, confirm=args.confirm_dangerous))


if __name__ == "__main__":
    main()
